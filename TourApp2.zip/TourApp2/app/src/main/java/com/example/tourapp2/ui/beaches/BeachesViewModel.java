package com.example.tourapp2.ui.beaches;

import androidx.lifecycle.ViewModel;

import com.example.tourapp2.ListModel;

import java.util.ArrayList;
import java.util.List;

public class BeachesViewModel extends ViewModel {
    private List<ListModel> beaches = new ArrayList<>();

    public BeachesViewModel() {
        listOfBeaches();
    }

    private void listOfBeaches() {
        beaches.add(new ListModel("https://www.touropia.com/gfx/d/best-beaches-in-egypt/fjord_bay_taba.jpg?v=ee36b0f1881db319c894184d679f667c"
                ,"Fjord Bay, Taba"
                ,"Located around 15-kilometers away from the small Egyptian town of Taba, near the border with neighboring Eilat in Israel, is a piece of picture-perfect paradise. Fjord Bay is the ideal location for diving, whether you have hundreds of hours of diving experience under your belt or you fancy giving it a go for the first time. The reason this place is such an amazing spot to dive in is down to the massive bed of coral that lies at the bottom of the fjord. An impressive 24-meters in depth, it’s hard to believe the sheer amount of fish and the diversity of marine life that lives among the reef. It’s nice to know that a healthy reef is an indication of clean water and good ecological balance. The fjord itself is a deep blue cove that is protected on three sides by a mountain range, which is great for hiking and taking in panoramic views over the fjord."));
        beaches.add(new ListModel("https://www.touropia.com/gfx/d/best-beaches-in-egypt/ras_abu_galoum.jpg?v=9aff35f07d6e6731044c8cbfb726043b"
                ,"Ras Abu Galoum, Dahab"
                ,"If you are looking for a stunning spot to do some snorkeling or diving, then Ras Abu Galoum is a brilliant choice. Situated close to a traditional Bedouin settlement – around 15-kilometers from the small coastal town of Dahab on the southeast coast of the Sinai Peninsula – is this sparklingly blue patch of ocean. This desert diving paradise is a feast for the eyes; the stunning seascape contrasts brilliantly with the arid rocky land and makes for a very special spot to visit. Arrive across the desert on camel-back before diving into the depths of the Red Sea, and experience for yourself the magnificence of its underwater landscape. Hard and soft coral create the perfect environment for angelfish, parrotfish and Picasso fish, amongst others, so make sure to bring your underwater camera"));
        beaches.add(new ListModel("https://www.touropia.com/gfx/d/best-beaches-in-egypt/nuweiba.jpg?v=1"
                ," Nuweiba"
                ,"Nuweiba was once a thriving beach resort in the 1970’s, and was on the up until politics and relations with Israel meant that the beautiful beach was left to slide into decline. The beach is now a simple, low-key place, with the most interesting part home to a Bedouin village. Located on the coast of the Gulf of Aqaba, Nuweiba city may pale in comparison to developed resorts like Sharm El Sheikh, but its lack of infrastructure also adds to the charm. Now a popular stop-off on the Egyptian backpacking trail, the seven-kilometer long stretch of sand translates as ‘bubbling springs’ in Arabic. It is a pleasant spot to spend a few days soaking up traditional culture and exploring the natural beauty of the area. South Cove, a short drive away, is a great little spot for diving, and treks to the Coloured Canyon can be arranged through the Bedouin village."));
        beaches.add(new ListModel("https://www.touropia.com/gfx/d/best-beaches-in-egypt/mahmya_island.jpg?v=fc6f68b9d3b482f0a2f289e33bcf9a12"
                ,"Mahmya Island"
                ,"If you are looking for a scuba diving Shangri La, Mahmya Island in the Giftun Island National Park is the place for you. An adventurous 45-minutes by boat from Hurghada, spend the day here snorkeling among the coral reefs and underwater garden in the most picturesque part of the Red Sea. Visiting the national park and the magnificence of Mahmya is like an exotic escape. Delve into the depths of the water and experience a world of rainbow fish and dolphins. It might get more than a little busy here with tour groups during high season, but the focus is on ecotourism and the support of the Red Sea’s delicate aquatic ecosystem. Visiting the island is experience you won’t forget."));
    }



    public List<ListModel> getBeaches() {
        return beaches;
    }
}
