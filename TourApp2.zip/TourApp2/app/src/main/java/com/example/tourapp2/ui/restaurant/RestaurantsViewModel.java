package com.example.tourapp2.ui.restaurant;

import androidx.lifecycle.ViewModel;

import com.example.tourapp2.ListModel;

import java.util.ArrayList;
import java.util.List;

public class RestaurantsViewModel extends ViewModel {
    private List<ListModel> restaurants = new ArrayList<>();

    public RestaurantsViewModel() {
        listOfRestaurants();
    }

    private void listOfRestaurants() {
        restaurants.add(new ListModel("https://assets.cairo360.com/app/uploads/2011/10/article_original_2827_20111910_504517620-600x323.jpeg"
                , "Lai Thai"
                , "No doubt Lai Thai is the best place which is placed top position in list of restaurants. Its exterior and interior design is heavily furnished with attractive look. The food is so tasty and awesome one where your saliva comes out from mouth before taking the food"));
        restaurants.add(new ListModel("https://d1vp8nomjxwyf1.cloudfront.net/wp-content/uploads/sites/87/2017/02/02160813/jungle_aqua_park_aqua_park_restaurant_gallery_01.jpg"
                , "Aqua"
                ,"Two reasons are behind while you visit this restaurant. Firstly, it is in Nile side. It is one of the places which are foodie’s paradise who would like to sink their food before soothing sight of the serene Nile. Secondly, seafood serves here where great delicious tasty and amazing food is here"));
        restaurants.add(new ListModel("https://media-cdn.tripadvisor.com/media/photo-s/15/22/0e/c0/abou-el-sid-dining-area.jpg"
                ,"About el Sid"
                ,"After taking the bite of local cuisines Egypt trip will be fulfilled otherwise not. Well! Décor of food and ambiance of restaurant is the high public demand. Otherwise your table will be empty and get empty hand with empty bill"));
        restaurants.add(new ListModel("https://scontent.faly2-2.fna.fbcdn.net/v/t1.0-9/67714375_502885676921375_8808973964136153088_o.jpg?_nc_cat=106&_nc_oc=AQm7zcewHFvyBJIy2seGus5txXqpP2qoaE8mro0Wudfe4aQrnOQJoej6yXdS5Jr6zhw&_nc_ht=scontent.faly2-2.fna&oh=4e27f3f4dca16458f1d555f17782df79&oe=5DD2A135"
                ,"PO SIGNATURE"
                ,"P.O signature The Spinning Grill Kitchen will definitely be on your list this year. They have made the FRESHEST bread, the FINEST meat, and the most INTENSE burger for you. The result from THEIR Burger ingredient, texture, flavor will knock your socks off. You just need to TRY IT NOW.When they thought about it they decided their signature won't be only burger. They have CHICKEN signatures served in their buttered & toasted buns that will satisfy all your cravings.their variety of BURGERS and CHICKEN will guarantee you a mouth-watering experience to share with your friends."));

    }



    public List<ListModel> getRestaurants() {
        return restaurants;
    }
}
