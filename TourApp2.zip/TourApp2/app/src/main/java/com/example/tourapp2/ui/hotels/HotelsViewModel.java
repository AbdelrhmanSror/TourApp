package com.example.tourapp2.ui.hotels;

import androidx.lifecycle.ViewModel;

import com.example.tourapp2.ListModel;

import java.util.ArrayList;
import java.util.List;

public class HotelsViewModel extends ViewModel {
    private List<ListModel> hotels = new ArrayList<>();

    public HotelsViewModel() {
        listOfHotels();
    }

    private void listOfHotels() {
        hotels.add(new ListModel("https://images.yamsafer.me/aliens/141350/large/hotels/5000000/4730000/4726800/4726749/e9d35894.jpg"
                , "La Villa Boutique Hotel, Alexandria:"
                , "Built in the early 1920’s by Mustafa Fahmy Pasha; the personal architect of King Farouk I, this building has stood there; accommodating royalty and majesty. Having one of the only 2 hand-carved wooden stair cases sent directly from Paris, France, the other which is currently in the Montazah Royal Palace. Along with paintings and antiques from around the world, especially the famous painting of Baroness Marie Alexandrine von Vetsera; the star of the famous Mayerling Palace tragedy in Austria (19 March 1871 – 30 January 1889)."));
        hotels.add(new ListModel("https://pix10.agoda.net/hotelImages/189/189412/189412_13081822360014400486.jpg?s=1024x768"
                , "El Salamlek Palace Hotel, Alexandria"
                , "Nestled on a hill overlooking the royal Mediterranean bay, take a journey into the glamorous past, a world of legendary elegance and opulence.Built in 1892 by the Khedive Abbas Helmi II, the palace was intended to be a hunting lodge and was surrounded by a man made jungle; the grounds were stocked with game for the hunting pleasure of the Khedive and his guests. Over the years the palace served as a royal resort under King Fouad I and during the reign of King Farouk I, the palace was used as his summer office and a guest house for his valuable visitors."));
        hotels.add(new ListModel("https://www.uniqhotels.com/media/hotels/66/4.jpg"
                , "Adrère Amellal Desert Ecolodge, Siwa"
                , "An out of this world luxury eco-hotel, set in a corner in the magical, scenic Siwa oasis. The entire hotel is built with locally sourced materials, with nothing imported from outside the immediate perimeter of the hotel. Even the furniture is made from local trees. There’s no electricity, no AC’s, only time-honoured oil lamps and a natural breeze"));
        hotels.add(new ListModel("https://s-ec.bstatic.com/images/hotel/max1024x768/174/174084227.jpg"
                , "Le Riad Hôtel de Charme, Cairo"
                , "Tucked away in The Grand Street of Historic Islamic Cairo—Al-Mu’izz li-Deen Illah Street, sits Le Riad Hôtel de Charme, a mere 5 minutes walking distance from Khan Al-Khalili. With only 17 very private suites facing Al-Darb Al-Asfar alley and its exceptional Ottoman era houses and a roof garden with a panoramic view of the 1000 minarets of Cairo, the ancient city walls, the Moqattam hills, and the citadel of Salah A-Din and the great Mosque of Mohamed Ali.Set in an old building from the 1960s, it was lovingly transformed by a pair of art lovers; Youssef Takla, a Syrian man and Véronique Sedro, a French woman, with an exquisite dream that turned into a reality of mashrabeyas, antiques and arches invoking the rich history of its surroundings."));

    }

    public List<ListModel> getHotels (){
        return hotels;
    }
}
