package com.example.tourapp2.ui.places;

import androidx.lifecycle.ViewModel;

import com.example.tourapp2.ListModel;

import java.util.ArrayList;
import java.util.List;

public class PlacesViewModel extends ViewModel {
    private List<ListModel> places = new ArrayList<>();

    public PlacesViewModel() {
        listOfPlaces();
    }

    private void listOfPlaces() {
        places.add(new ListModel("https://www.touropia.com/gfx/d/true-pyramids-of-the-world/giza_necropolis.jpg?v=48ea8829c5a2f321becee2e738673a4d"
                , "Giza Necropolis"
                , "The Pyramids of Giza, situated in the immediate vicinity of the southwestern suburbs of Cairo are the undisputable top attractions in Egypt. The pyramids at Giza were built over the span of three generations – by Khufu, his second reigning son Khafre, and Menkaure. The Great Pyramid of Khufu is an awe-inspiring 139 meters (455 feet) high making it the largest pyramid in Egypt, although nearby Khafre’s Pyramid appears to be larger as it is build at a higher elevation."));
        places.add(new ListModel("https://www.touropia.com/gfx/d/ancient-egyptian-temples/karnak.jpg?v=abd4e1b26a795eba99dd6e2fd553ad60"
                , "Karnak", "Although badly ruined, few sites in Egypt are more impressive than Karnak. It is the largest ancient religious site ever built, and represents the combined achievement of many generations of Egyptian builders. The Temple of Karnak actually consists of three main temples, smaller enclosed temples, and several outer temples located about 2.5 kilometers north of Luxor. One of most famous structures of Karnak is the Hypostyle Hall, a hall area of 5,000 m2 (50,000 sq ft) with 134 massive columns arranged in 16 rows."));
        places.add(new ListModel("https://www.touropia.com/gfx/d/best-dive-spots-in-the-world/red_sea_reef.jpg?v=1"
                , "Red Sea Reef"
                , "The Red Sea, off the coast of Egypt, is one of the most beautiful places in the world to go diving. The waters of the Red Sea are renowned for their spectacular visibility and features some of the most exotic seascapes. With its wide expanse of coral formation on the reefs, it is home to thousands of different sea creatures. Red Sea beach resorts are located on both sides of the sea, on the east side and part of the Sinai peninsula is the long established Sharm el Sheikh and its neo-hippy counterpart, Dahab. On the west coast of the Red Sea lies relatively old and touristy Hurghada and a cluster of new resort towns."));
        places.add(new ListModel("https://www.touropia.com/gfx/d/top-attractions-in-egypt/river_nile_cruise.jpg?v=729a33c8078fa3629fdd252d758ebe77"
                , "River Nile Cruise"
                , "Cruising the Nile is a popular way of visiting upper Egypt. The Nile River has been Egypt’s lifeline since ancient times and there is no better way to trace the passage of Egypt’s history than to follow the course of the Nile. Almost all Egyptian cruise ships travel the Luxor-Aswan route which is safe, scenic and terminates at two of Egypt’s most important towns. Taking a Felucca down the Nile is an adventurous option. Feluccas are sail boats that have been used on the Nile since antiquity. A Felucca is not quite as comfortable as a luxury cruise ship but nothing can beat sailing in a quiet rig that was designed thousands of years ago."));


    }

    public List<ListModel> getPlaces() {
        return places;
    }
}
